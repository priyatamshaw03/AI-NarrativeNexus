import logo from "./logo.svg";
import user_group from "./user_group.png";
import menu_icon_dark from "./menu_icon_dark.svg";
import sun_icon from "./sun_icon.svg";
import moon_icon from "./moon_icon.svg";
import arrow_icon from "./arrow_icon.svg";
import menu_icon from "./menu_icon.svg";
import close_icon from "./close_icon.svg";
import howitswork from "./howitswork.jpg";

export const assets = {
    logo,
    user_group,
    arrow_icon,
    menu_icon,
    close_icon,
    menu_icon_dark,
    sun_icon,
    moon_icon,
    howitswork,
};

