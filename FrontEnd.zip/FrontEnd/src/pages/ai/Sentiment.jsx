// src/pages/ai/Summarization.jsx
import React, { useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Pie } from 'react-chartjs-2';
import 'chart.js/auto';

const Sentiment = () => {
  const { setSentimentData, setInsights } = useOutletContext();

  const data = {
    labels: ['Positive', 'Neutral', 'Negative'],
    datasets: [{
      data: [50, 30, 20],
      backgroundColor: ['#34d399', '#facc15', '#f87171']
    }]
  };

  useEffect(() => {
    setSentimentData({
      chartData: data,
      text: 'Overall customer sentiment based on the analyzed text.',
      topics: [
        { name: 'Customer Experience', keywords: ['feedback', 'support'] },
        { name: 'Pricing', keywords: ['value', 'subscription'] }
      ]
    });
    setInsights(prev => [
      ...prev,
      'Sentiment analysis performed with a focus on customer feedback.'
    ]);
  }, []);

  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">Sentiment Analysis</h2>
      <div className='grid md:grid-cols-2 gap-4 my-6'>
        <div className="max-w-xs mx-auto mb-6">
        <Pie data={data} />
      </div>
      <div className="bg-slate-500 p-4 rounded mb-4">
        <h3 className="font-semibold mb-2">Analysis Text</h3>
        <p>Overall customer sentiment based on the analyzed text.</p>
      </div>
      <div className="bg-slate-500 p-4 rounded">
        <h3 className="font-semibold mb-2">Topics with Keywords</h3>
        {[
          { name: 'Customer Experience', keywords: ['feedback', 'support'] },
          { name: 'Pricing', keywords: ['value', 'subscription'] }
        ].map((topic, i) => (
          <div key={i} className="mb-2">
            <p className="font-bold">{topic.name}</p>
            <p>Keywords: {topic.keywords.join(', ')}</p>
          </div>
        ))}
      </div>
      </div>
    </div>
  );
};

export default Sentiment;
