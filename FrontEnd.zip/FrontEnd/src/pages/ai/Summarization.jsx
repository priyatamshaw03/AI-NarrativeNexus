import React from 'react'

const Summarization = () => {
  return (
    <div>Summarization</div>
  )
}

export default Summarization